
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "gate.decodo.com",
                port: parseInt(10001)
              },
              bypassList: ["localhost"]
            }
          };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "spzwebo9sb",
                    password: "o30vLtt2e+ZOzinPm9"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    